package TestngProject;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Activity9 {
	WebDriver driver;
				
	@Test
	public void travTable2() throws InterruptedException {
		WebDriver driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://alchemy.hguy.co/crm/");
		driver.findElement(By.id("user_name")).sendKeys("admin");
		driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		
		driver.findElement(By.xpath("//a[@id='grouptab_0']")).click();
		driver.findElement(By.xpath("//a[@id='grouptab_0']")).click();
		
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(By.xpath("//a[@id='grouptab_0']"))).perform();
		driver.findElement(By.xpath("//a[@id='moduleTab_9_Leads']")).click();
		
		Thread.sleep(3000);
		List<WebElement> li = driver.findElements(By.xpath("//td[@class=' inlineEdit']"));
		
		int i = 0;
		for (WebElement l:li) {
			System.out.println(l.getText());
			i=i+1;
			if (i>10)
				break;
			}
List<WebElement> Mi = driver.findElements(By.xpath("//td[@class='hidden-xs hidden-sm inlineEdit']"));
		
		int j = 0;
		for (WebElement l:Mi) {
			System.out.println(l.getText());
			j=j+1;
			if (j>9)
				break;
			}
}

}
