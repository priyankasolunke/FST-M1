package TestngProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Activity6 {
	@Test
	public void Actavail() {
		WebDriver driver=new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/crm/");
		driver.findElement(By.id("user_name")).sendKeys("admin");
		driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		
		boolean s= driver.findElement(By.xpath("//a[@id='grouptab_3']")).isEnabled();
		if (s==true)
		System.out.println("the Acticities option in Menu is available and clickable");
		else
			System.out.println("The Activities Menu is not available");
	
	driver.close();
	}	
}
