package TestngProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Activity4 {
@Test
public void logIn() {
	WebDriver driver=new FirefoxDriver();
	driver.get("https://alchemy.hguy.co/crm/");
	driver.findElement(By.id("user_name")).sendKeys("admin");
	driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
	driver.findElement(By.xpath("//input[@name='Login']")).click();
	
	System.out.println("ttile of the page is : "+driver.getTitle());
	String s= driver.getCurrentUrl();
	System.out.println("logged in");
	if (s.contentEquals("https://alchemy.hguy.co/crm/index.php?module=Home&action=index")) {
		System.out.println("Homepage has opened");
		driver.close();}
}
}
