package TestngProject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Activity1 {

	@Test
	public void logIn(){
	WebDriver driver=new FirefoxDriver();
	driver.get("https://alchemy.hguy.co/crm/");
	
	System.out.println("ttile of the page is : "+driver.getTitle());
	String s= driver.getTitle();
	System.out.println("fetched title");
	if (s.contentEquals("SuiteCRM")) {
		System.out.println("In if block");
		driver.close();
	}
		
	
	}	
}
