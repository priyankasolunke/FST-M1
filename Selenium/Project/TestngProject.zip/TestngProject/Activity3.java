package TestngProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Activity3 {
	@Test
	public void getcopytext() {

		WebDriver driver=new FirefoxDriver();
		driver.get("http://alchemy.hguy.co/crm");
		String s=driver.findElement(By.xpath("//a[@id='admin_options']")).getText();
		System.out.println("the copy right text is : "+s);
		driver.close();		
	}

}
