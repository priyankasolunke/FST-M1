package TestngProject;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.*;

public class Activity8 {
	WebDriver driver;
	@BeforeClass
	public void invoke() {

		WebDriver driver=new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}
	
	@Test
	public void travTable1() throws InterruptedException {
		driver.get("https://alchemy.hguy.co/crm/");
		driver.findElement(By.id("user_name")).sendKeys("admin");
		driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(By.xpath("//a[@id='grouptab_0']"))).perform();
		driver.findElement(By.xpath("//a[@id='moduleTab_9_Accounts']")).click();
		System.out.println("The first 5 odd rows of the table staring from 1st are as follow : ");
		Thread.sleep(5000);
		List<WebElement> li = driver.findElements(By.xpath("//tr[@class='oddListRowS1']"));
		int i = 0;
		for (WebElement l:li) {
		System.out.println(l.getText());
		i=i+1;
		if (i>5)
			break;
		}
		/*
		String[] array = li.toArray(new String[0]);
		for (int i=0;i<5;i++) {
			System.out.println("Row"+i+ " " +array[i]);
			
		}*/
		/*
		System.out.println(driver.findElement(By.xpath("(//tr[@class='oddListRowS1'])[1]")).getText());
		System.out.println(driver.findElement(By.xpath("(//tr[@class='oddListRowS1'])[3]")).getText());
		System.out.println(driver.findElement(By.xpath("(//tr[@class='oddListRowS1'])[5]")).getText());
		System.out.println(driver.findElement(By.xpath("(//tr[@class='oddListRowS1'])[7]")).getText());
		System.out.println(driver.findElement(By.xpath("(//tr[@class='oddListRowS1'])[9]")).getText());
		*/
}

}
