package TestngProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Activity2 {
public void printurl() {
		WebDriver driver=new FirefoxDriver();
		driver.get("http://alchemy.hguy.co/crm");
		System.out.println("The url of the current web page is : "+driver.getCurrentUrl());
}
}
