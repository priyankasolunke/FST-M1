package TestngProject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Activity7 {
	@Test
	public void addinfo() throws InterruptedException {
		WebDriver driver=new FirefoxDriver();
		//WebDriverWait wait = new WebDriverWait(driver,50);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://alchemy.hguy.co/crm/");
		driver.findElement(By.id("user_name")).sendKeys("admin");
		driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(By.xpath("//a[@id='grouptab_0']"))).perform();
		driver.findElement(By.xpath("//a[@id='moduleTab_9_Leads']")).click();
		System.out.println(driver.findElement(By.xpath("(//span[@title='Additional Details'])[2]")).isDisplayed());
		Thread.sleep(10000);
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='Additional Details'])[2]")));
		
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("(//span[@title='Additional Details'])[2]")).click();	
		String s=driver.findElement(By.xpath("(//span[@class='phone'])[1]")).getText();
		System.out.println("Mobile Number is : "+s);
		//"(//button[@title='Close'])[4]"
		driver.findElement(By.xpath("(//span[@class='ui-button-icon-primary ui-icon ui-icon-closethick'])[4]")).click();
		System.out.println("closed more info pop up box");
		driver.close();
		System.out.println("closed browser also");
	}			
}
