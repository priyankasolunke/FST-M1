package TestngProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ActivityCRM {
WebDriver driver;
	@Test (priority = 0)
	public void logIn(){
	WebDriver driver=new FirefoxDriver();
	driver.get("https://alchemy.hguy.co/crm/");
	driver.findElement(By.id("user_name")).sendKeys("admin");
	driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
	driver.findElement(By.xpath("//input[@name='Login']")).click();
	}
	@Test (priority = 1)
	public void getTitle() {
	WebDriver driver = new FirefoxDriver();
	System.out.println("ttile of the page is : "+driver.getTitle());
	String s= driver.getTitle();
	System.out.println("in second test");
	if (s=="SuiteCRM") {
		driver.close();
		
	}
	}

}
