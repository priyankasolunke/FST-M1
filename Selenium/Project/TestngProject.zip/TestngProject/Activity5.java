package TestngProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Activity5 {
	@Test
	public void getColor() {
		WebDriver driver=new FirefoxDriver();
		driver.get("https://alchemy.hguy.co/crm/");
		driver.findElement(By.id("user_name")).sendKeys("admin");
		driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		
		boolean s= driver.findElement(By.xpath("//div[@id='toolbar']")).isDisplayed();
		System.out.println(s);
		String color =driver.findElement(By.xpath("//div[@id='toolbar']")).getCssValue("color");
		System.out.println("the color of navigation Menu is : "+color);
		driver.close();
	}
}
