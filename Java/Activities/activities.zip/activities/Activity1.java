package activities;

public class Activity1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Car objcar=new Car();
objcar.make= 2014;
objcar.Colour = "Black";
objcar.transmission = "Manual";

objcar.displaycharacteristics();
objcar.accelerate();
objcar.brake();

	}

}
